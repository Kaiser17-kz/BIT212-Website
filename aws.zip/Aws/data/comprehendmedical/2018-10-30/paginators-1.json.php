<?php
// This file was auto-generated from sdk-root/src/data/comprehendmedical/2018-10-30/paginators-1.json
return [ 'pagination' => [],];
