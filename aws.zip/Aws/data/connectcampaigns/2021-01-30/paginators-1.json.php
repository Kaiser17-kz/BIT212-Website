<?php
// This file was auto-generated from sdk-root/src/data/connectcampaigns/2021-01-30/paginators-1.json
return [ 'pagination' => [ 'ListCampaigns' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'campaignSummaryList', ], ],];
