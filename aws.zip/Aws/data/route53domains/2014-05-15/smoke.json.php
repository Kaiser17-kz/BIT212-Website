<?php
// This file was auto-generated from sdk-root/src/data/route53domains/2014-05-15/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-east-1', 'testCases' => [ [ 'operationName' => 'ListDomains', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'GetDomainDetail', 'input' => [ 'DomainName' => 'fake-domain-name', ], 'errorExpectedFromService' => true, ], ],];
