<?php
// This file was auto-generated from sdk-root/src/data/workspaces-thin-client/2023-08-22/paginators-1.json
return [ 'pagination' => [ 'ListDevices' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'devices', ], 'ListEnvironments' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'environments', ], 'ListSoftwareSets' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'softwareSets', ], ],];
