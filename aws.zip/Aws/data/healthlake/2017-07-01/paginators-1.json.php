<?php
// This file was auto-generated from sdk-root/src/data/healthlake/2017-07-01/paginators-1.json
return [ 'pagination' => [ 'ListFHIRDatastores' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'ListFHIRExportJobs' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'ListFHIRImportJobs' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];
